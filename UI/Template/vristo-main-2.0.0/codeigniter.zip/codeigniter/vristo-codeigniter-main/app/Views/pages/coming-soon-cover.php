<?= $this->extend('components/layout/auth.php') ?>

<?= $this->section('content') ?>


<div x-data="comingsoon">
    <div class="absolute inset-0">
        <img src="<?php echo base_url('assets/images/auth/bg-gradient.png') ?>" alt="image" class="h-full w-full object-cover" />
    </div>
    <div class="relative flex min-h-screen items-center justify-center bg-[url(/assets/images/auth/map.png)] bg-cover bg-center bg-no-repeat px-6 py-10 dark:bg-[#060818] sm:px-16">
        <img src="<?php echo base_url('assets/images/auth/coming-soon-object1.png') ?>" alt="image" class="absolute left-0 top-1/2 h-full max-h-[893px] -translate-y-1/2" />
        <img src="<?php echo base_url('assets/images/auth/coming-soon-object2.png') ?>" alt="image" class="absolute left-24 top-0 h-40 md:left-[30%]" />
        <img src="<?php echo base_url('assets/images/auth/coming-soon-object3.png') ?>" alt="image" class="absolute right-0 top-0 h-[300px]" />
        <img src="<?php echo base_url('assets/images/auth/polygon-object.svg') ?>" alt="image" class="absolute bottom-0 end-[28%]" />
        <div class="relative flex w-full max-w-[1502px] flex-col justify-between overflow-hidden rounded-md bg-white/60 text-center backdrop-blur-lg dark:bg-black/50 lg:min-h-[758px] lg:flex-row lg:gap-10 xl:gap-0">
            <div class="relative hidden w-full items-center justify-center p-5 lg:inline-flex lg:max-w-[835px] ltr:xl:-ml-24 ltr:xl:skew-x-[14deg] rtl:xl:-mr-24 rtl:xl:skew-x-[-14deg]" style="background: linear-gradient(225deg, rgba(239, 18, 98, 1) 0%, rgba(67, 97, 238, 1) 100%)">
                <div class="absolute inset-y-0 w-8 from-primary/10 via-transparent to-transparent ltr:-right-10 ltr:bg-gradient-to-r rtl:-left-10 rtl:bg-gradient-to-l xl:w-16 ltr:xl:-right-20 rtl:xl:-left-20"></div>
                <div class="ltr:xl:-skew-x-[14deg] rtl:xl:skew-x-[14deg]">
                    <a href="/" class="w-48 block lg:w-72 mx-auto 2xl:m-0">
                        <img src="<?php echo base_url('assets/images/auth/logo-white.svg') ?>" alt="Logo" class="w-full" />
                    </a>
                    <div class="mt-24 hidden w-full max-w-[430px] rtl:rotate-y-180 lg:block">
                        <img src="<?php echo base_url('assets/images/auth/coming-soon-cover.svg') ?>" alt="Cover Image" class="w-full" />
                    </div>
                </div>
            </div>
            <div class="relative w-full px-4 pb-16 pt-6 sm:px-6 lg:max-w-[667px]">
                <div class="mx-auto mt-5 w-full max-w-[550px] lg:mt-16">
                    <a href="/" class="mb-8 block lg:hidden">
                        <img src="<?php echo base_url('assets/images/logo.svg') ?>" alt="Logo" class="mx-auto w-10" />
                    </a>
                    <div class="mb-12">
                        <h1 class="text-3xl font-extrabold uppercase !leading-snug text-primary md:text-4xl">Coming Soon</h1>
                        <p class="text-base font-bold leading-normal text-white-dark">We will be here in a shortwhile.....</p>
                    </div>
                    <div class="mb-16 flex items-center justify-center gap-2 text-xl font-bold leading-none text-primary sm:text-2xl md:mb-24 md:gap-4 md:text-[50px]" x-init="setTimerDemo1">
                        <div class="relative inline-flex h-12 w-14 items-center justify-center rounded-md bg-primary-light p-2 sm:h-16 sm:w-16 md:h-24 md:min-w-[120px]">
                            <div class="absolute inset-1 flex flex-col gap-1">
                                <span class="h-full w-full rounded-md bg-primary/[12%]"></span>
                                <span class="h-full w-full rounded-md bg-white"></span>
                            </div>
                            <span class="relative" x-text="demo1.days"></span>
                        </div>
                        <span>:</span>
                        <div class="relative inline-flex h-12 w-12 items-center justify-center rounded-md bg-primary-light p-2 sm:h-16 sm:w-16 md:h-24 md:min-w-[96px]">
                            <div class="absolute inset-1 flex flex-col gap-1">
                                <span class="h-full w-full rounded-md bg-primary/[12%]"></span>
                                <span class="h-full w-full rounded-md bg-white"></span>
                            </div>
                            <span class="relative" x-text="demo1.hours"></span>
                        </div>
                        <span>:</span>
                        <div class="relative inline-flex h-12 w-12 items-center justify-center rounded-md bg-primary-light p-2 sm:h-16 sm:w-16 md:h-24 md:min-w-[96px]">
                            <div class="absolute inset-1 flex flex-col gap-1">
                                <span class="h-full w-full rounded-md bg-primary/[12%]"></span>
                                <span class="h-full w-full rounded-md bg-white"></span>
                            </div>
                            <span class="relative" x-text="demo1.minutes"></span>
                        </div>
                        <span>:</span>
                        <div class="relative inline-flex h-12 w-12 items-center justify-center rounded-md bg-primary-light p-2 sm:h-16 sm:w-16 md:h-24 md:min-w-[96px]">
                            <div class="absolute inset-1 flex flex-col gap-1">
                                <span class="h-full w-full rounded-md bg-primary/[12%]"></span>
                                <span class="h-full w-full rounded-md bg-white"></span>
                            </div>
                            <span class="relative" x-text="demo1.seconds"></span>
                        </div>
                    </div>
                    <div class="mb-20 md:mb-32">
                        <h2 class="text-lg font-bold uppercase dark:text-white sm:text-xl">Subscribe to get notified!</h2>
                        <div class="relative mb-10 mt-8">
                            <input type="email" placeholder="mail@gmail.com" class="form-input mb-5 py-3.5 placeholder:text-base placeholder:text-white-dark sm:mb-0 sm:pe-32" />
                            <button type="button" class="btn btn-gradient end-1.5 top-1/2 inline-flex border-0 px-4 py-1.5 text-base shadow-none sm:absolute sm:-translate-y-1/2" @click="window.location='/'">
                                Subscribe
                            </button>
                        </div>
                        <ul class="flex justify-center gap-3.5">
                            <li>
                                <a href="javascript:" class="inline-flex h-8 w-8 items-center justify-center rounded-full p-0 transition hover:scale-110" style="background: linear-gradient(135deg, rgba(239, 18, 98, 1) 0%, rgba(67, 97, 238, 1) 100%)">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M8 2.05C9.925 2.05 10.1875 2.05 10.975 2.05C11.675 2.05 12.025 2.225 12.2875 2.3125C12.6375 2.4875 12.9 2.575 13.1625 2.8375C13.425 3.1 13.6 3.3625 13.6875 3.7125C13.775 3.975 13.8625 4.325 13.95 5.025C13.95 5.8125 13.95 5.9875 13.95 8C13.95 10.0125 13.95 10.1875 13.95 10.975C13.95 11.675 13.775 12.025 13.6875 12.2875C13.5125 12.6375 13.425 12.9 13.1625 13.1625C12.9 13.425 12.6375 13.6 12.2875 13.6875C12.025 13.775 11.675 13.8625 10.975 13.95C10.1875 13.95 10.0125 13.95 8 13.95C5.9875 13.95 5.8125 13.95 5.025 13.95C4.325 13.95 3.975 13.775 3.7125 13.6875C3.3625 13.5125 3.1 13.425 2.8375 13.1625C2.575 12.9 2.4 12.6375 2.3125 12.2875C2.225 12.025 2.1375 11.675 2.05 10.975C2.05 10.1875 2.05 10.0125 2.05 8C2.05 5.9875 2.05 5.8125 2.05 5.025C2.05 4.325 2.225 3.975 2.3125 3.7125C2.4875 3.3625 2.575 3.1 2.8375 2.8375C3.1 2.575 3.3625 2.4 3.7125 2.3125C3.975 2.225 4.325 2.1375 5.025 2.05C5.8125 2.05 6.075 2.05 8 2.05ZM8 0.737503C5.9875 0.737503 5.8125 0.737503 5.025 0.737503C4.2375 0.737503 3.7125 0.912504 3.275 1.0875C2.8375 1.2625 2.4 1.525 1.9625 1.9625C1.525 2.4 1.35 2.75 1.0875 3.275C0.912504 3.7125 0.825003 4.2375 0.737503 5.025C0.737503 5.8125 0.737503 6.075 0.737503 8C0.737503 10.0125 0.737503 10.1875 0.737503 10.975C0.737503 11.7625 0.912504 12.2875 1.0875 12.725C1.2625 13.1625 1.525 13.6 1.9625 14.0375C2.4 14.475 2.75 14.65 3.275 14.9125C3.7125 15.0875 4.2375 15.175 5.025 15.2625C5.8125 15.2625 6.075 15.2625 8 15.2625C9.925 15.2625 10.1875 15.2625 10.975 15.2625C11.7625 15.2625 12.2875 15.0875 12.725 14.9125C13.1625 14.7375 13.6 14.475 14.0375 14.0375C14.475 13.6 14.65 13.25 14.9125 12.725C15.0875 12.2875 15.175 11.7625 15.2625 10.975C15.2625 10.1875 15.2625 9.925 15.2625 8C15.2625 6.075 15.2625 5.8125 15.2625 5.025C15.2625 4.2375 15.0875 3.7125 14.9125 3.275C14.7375 2.8375 14.475 2.4 14.0375 1.9625C13.6 1.525 13.25 1.35 12.725 1.0875C12.2875 0.912504 11.7625 0.825003 10.975 0.737503C10.1875 0.737503 10.0125 0.737503 8 0.737503Z" fill="white" />
                                        <path d="M8 4.2375C5.9 4.2375 4.2375 5.9 4.2375 8C4.2375 10.1 5.9 11.7625 8 11.7625C10.1 11.7625 11.7625 10.1 11.7625 8C11.7625 5.9 10.1 4.2375 8 4.2375ZM8 10.45C6.6875 10.45 5.55 9.4 5.55 8C5.55 6.6875 6.6 5.55 8 5.55C9.3125 5.55 10.45 6.6 10.45 8C10.45 9.3125 9.3125 10.45 8 10.45Z" fill="white" />
                                        <path d="M11.85 5.025C12.3333 5.025 12.725 4.63325 12.725 4.15C12.725 3.66675 12.3333 3.275 11.85 3.275C11.3668 3.275 10.975 3.66675 10.975 4.15C10.975 4.63325 11.3668 5.025 11.85 5.025Z" fill="white" />
                                    </svg>
                                </a>
                            </li>
                            <li>
                                <a href="javascript:" class="inline-flex h-8 w-8 items-center justify-center rounded-full p-0 transition hover:scale-110" style="background: linear-gradient(135deg, rgba(239, 18, 98, 1) 0%, rgba(67, 97, 238, 1) 100%)">
                                    <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M14 7C14 3.15 10.85 0 7 0C3.15 0 0 3.15 0 7C0 10.5 2.5375 13.3875 5.8625 13.9125V9.0125H4.1125V7H5.8625V5.425C5.8625 3.675 6.9125 2.7125 8.4875 2.7125C9.275 2.7125 10.0625 2.8875 10.0625 2.8875V4.6375H9.1875C8.3125 4.6375 8.05 5.1625 8.05 5.6875V7H9.975L9.625 9.0125H7.9625V14C11.4625 13.475 14 10.5 14 7Z" fill="white" />
                                    </svg>
                                </a>
                            </li>
                            <li>
                                <a href="javascript:" class="inline-flex h-8 w-8 items-center justify-center rounded-full p-0 transition hover:scale-110" style="background: linear-gradient(135deg, rgba(239, 18, 98, 1) 0%, rgba(67, 97, 238, 1) 100%)">
                                    <svg width="14" height="12" viewBox="0 0 14 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M14 1.625C13.475 1.8875 12.95 1.975 12.3375 2.0625C12.95 1.7125 13.3875 1.1875 13.5625 0.4875C13.0375 0.8375 12.425 1.0125 11.725 1.1875C11.2 0.6625 10.4125 0.3125 9.625 0.3125C7.7875 0.3125 6.3875 2.0625 6.825 3.8125C4.4625 3.725 2.3625 2.5875 0.875 0.8375C0.0875 2.15 0.525 3.8125 1.75 4.6875C1.3125 4.6875 0.875 4.5125 0.4375 4.3375C0.4375 5.65 1.4 6.875 2.7125 7.225C2.275 7.3125 1.8375 7.4 1.4 7.3125C1.75 8.45 2.8 9.325 4.1125 9.325C3.0625 10.1125 1.4875 10.55 0 10.375C1.3125 11.1625 2.8 11.6875 4.375 11.6875C9.7125 11.6875 12.6875 7.225 12.5125 3.1125C13.125 2.7625 13.65 2.2375 14 1.625Z" fill="white" />
                                    </svg>
                                </a>
                            </li>
                            <li>
                                <a href="javascript:" class="inline-flex h-8 w-8 items-center justify-center rounded-full p-0 transition hover:scale-110" style="background: linear-gradient(135deg, rgba(239, 18, 98, 1) 0%, rgba(67, 97, 238, 1) 100%)">
                                    <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M13.8512 7.15912C13.8512 6.66275 13.8066 6.18548 13.7239 5.72729H7.13116V8.43503H10.8984C10.7362 9.31003 10.243 10.0514 9.50162 10.5478V12.3041H11.7639C13.0875 11.0855 13.8512 9.29094 13.8512 7.15912Z" fill="white" />
                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M7.13089 14C9.0209 14 10.6054 13.3731 11.7636 12.3041L9.50135 10.5477C8.87454 10.9677 8.07272 11.2159 7.13089 11.2159C5.30771 11.2159 3.76452 9.9845 3.21407 8.32996H0.875427V10.1436C2.02725 12.4313 4.39453 14 7.13089 14Z" fill="white" />
                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M3.21435 8.32997C3.07435 7.90997 2.99481 7.46133 2.99481 6.99997C2.99481 6.5386 3.07435 6.08996 3.21435 5.66996V3.85632H0.875712C0.40162 4.80133 0.131165 5.87042 0.131165 6.99997C0.131165 8.12951 0.40162 9.19861 0.875712 10.1436L3.21435 8.32997Z" fill="white" />
                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M7.13089 2.7841C8.15862 2.7841 9.08135 3.13728 9.80681 3.83092L11.8145 1.82319C10.6023 0.693638 9.01772 0 7.13089 0C4.39453 0 2.02725 1.56864 0.875427 3.85637L3.21407 5.67001C3.76452 4.01546 5.30771 2.7841 7.13089 2.7841Z" fill="white" />
                                    </svg>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <p class="absolute bottom-6 w-full text-center dark:text-white">
                    © <span id="footer-year">2022</span>. VRISTO All Rights Reserved.
                </p>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener("alpine:init", () => {
        Alpine.data("comingsoon", () => ({
            timer1: null,
            demo1: {
                days: null,
                hours: null,
                minutes: null,
                seconds: null,
            },
            setTimerDemo1() {
                let date = new Date();
                date.setFullYear(date.getFullYear() + 1);
                let countDownDate = date.getTime();

                this.timer1 = setInterval(() => {
                    let now = new Date().getTime();

                    let distance = countDownDate - now;

                    this.demo1.days = Math.floor(distance / (1000 * 60 * 60 * 24));
                    this.demo1.hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                    this.demo1.minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
                    this.demo1.seconds = Math.floor((distance % (1000 * 60)) / 1000);

                    if (distance < 0) {
                        clearInterval(this.timer1);
                    }
                }, 500);
            },
        }));
    });
</script>

<?= $this->endSection() ?>